#pragma once

#include <stdexcept>
#include <cstddef>
#include <memory>
#include <vector>
#include <iterator>

/*
=================================================

                  STACK STORAGE

=================================================
*/

template <size_t N>
class StackStorage {
    alignas(alignof(std::max_align_t)) char data[N]{};
    char* current_pos = data;

public:
    char* get_data() {
      return data;
    }

    [[nodiscard]] char* get_current_pos() const {
        return current_pos;
    }

    void set_current_pos(char* new_pos) {
        current_pos = new_pos;
    }

    StackStorage(const StackStorage&) = delete;
    StackStorage& operator=(const StackStorage&) = delete;

    StackStorage() = default;

    [[nodiscard]] std::size_t remaining_space() const {
        return N - static_cast<std::size_t>(current_pos - data);
    }
};

/*
=================================================

                STACK ALLOCATOR

=================================================
*/

template <typename T, size_t N>
class StackAllocator {
    StackStorage<N>* storage;

public:
    using value_type = T;

    explicit StackAllocator(StackStorage<N>& storage)
        : storage(&storage) {}

    template <typename U>
    StackAllocator(const StackAllocator<U, N>& other)
        : storage(other.get_storage()) {}

    StackAllocator(const StackAllocator& other) = default;
    StackAllocator& operator=(const StackAllocator& other) = default;

    value_type* allocate(const std::size_t n) {
        const std::size_t total_size = sizeof(T) * n;
        std::size_t space = storage->remaining_space();
        void* ptr = storage->get_current_pos();
        void* aligned_ptr = std::align(alignof(T), total_size, ptr, space);
        if (!aligned_ptr) {
            throw std::bad_alloc();
        }
        storage->set_current_pos(static_cast<char*>(aligned_ptr) + total_size);
        return static_cast<value_type*>(aligned_ptr);
    }

    void deallocate(T*, std::size_t) noexcept {}

    StackStorage<N>* get_storage() const {
        return storage;
    }

    template <typename U>
    struct rebind {
        using other = StackAllocator<U, N>;
    };

    template <typename U>
    StackAllocator<U, N> select_on_container_copy_construction() const noexcept {
        return StackAllocator<U, N>(*storage);
    }

    template <typename U>
    bool operator==(const StackAllocator<U, N>& other) const noexcept {
        return storage == other.get_storage();
    }

    template <typename U>
    bool operator!=(const StackAllocator<U, N>& other) const noexcept {
        return !(*this == other);
    }
};

/*
=================================================

                 LIST ITERATORS

=================================================
*/

struct BaseNode {
    BaseNode* prev;
    BaseNode* next;

    BaseNode() : prev(nullptr), next(nullptr) {}

    BaseNode(BaseNode* prev, BaseNode* next) : prev(prev), next(next) {}
};

template <typename T>
struct Node : BaseNode {
    T value;

    Node() : value() {}

    explicit Node(const T& val) : value(val) {}

    explicit Node(T&& val) : value(std::move(val)) {}

    template<typename... UArgs>
    explicit Node(UArgs&&... args)
        : value(std::forward<UArgs>(args)...) {}
};

template<typename T, bool is_const = false, bool is_reverse = false>
class baseIterator {
    BaseNode* iterator_;

public:
  using iterator_category = std::bidirectional_iterator_tag;
  using value_type = std::conditional_t<is_const, const T, T>;
  using difference_type = std::ptrdiff_t;
  using node_type = std::conditional_t<is_const, const BaseNode*, BaseNode*>;
  using node_t = std::conditional_t<is_const, const Node<T>*, Node<T>*>;

  baseIterator() : iterator_(nullptr) {}

  explicit baseIterator(BaseNode* node) : iterator_(node) {}

  [[nodiscard]] BaseNode* node() const {
      return iterator_;
  }

  template<bool other_const, typename = std::enable_if_t<is_const >= other_const>>
  baseIterator(const baseIterator<T, other_const, is_reverse>& other)
      : iterator_(other.node()) {}

  value_type& operator*() const {
      return (static_cast<node_t>(iterator_))->value;
  }

  value_type* operator->() const {
    return &(static_cast<node_t>(iterator_))->value;
  }

  baseIterator<T, is_const> base() const noexcept {
    if constexpr (is_reverse) {
        return baseIterator<T, is_const>(iterator_->next);
    }
    else {
        return baseIterator<T, is_const>(iterator_);
    }
  }

/*
-------------------------------------------------

            ARITHMETIC OF ITERATORS

-------------------------------------------------
*/

  bool operator==(const baseIterator& other) const noexcept {
    return iterator_ == other.iterator_;
  }

  template<bool IsConst>
  bool operator==(const baseIterator<T, IsConst>& other) const noexcept {
    return node() == other.node();
  }

  bool operator!=(const baseIterator& other) const noexcept {
    return !(*this == other);
  }

  baseIterator& operator++() noexcept {
      if constexpr (is_reverse) {
          iterator_ = iterator_->prev;
      } else {
          iterator_ = iterator_->next;
      }
      return *this;
  }

  baseIterator operator++(int) noexcept {
    baseIterator temp = *this;
    ++(*this);
    return temp;
  }

  baseIterator& operator--() noexcept {
      if constexpr (is_reverse) {
          iterator_ = iterator_->next;
      } else {
          iterator_ = iterator_->prev;
      }
      return *this;
  }

  baseIterator operator--(int) noexcept {
    baseIterator temp = *this;
    --(*this);
    return temp;
  }

  baseIterator& operator+=(std::size_t n) {
    for (size_t i = 0; i < n; ++i) {
        if (is_reverse) {
            iterator_ = iterator_->prev;
        } else {
            iterator_ = iterator_->next;
        }
    }
    return *this;
  }

  baseIterator operator+(std::size_t n) const {
    baseIterator temp = *this;
    temp += n;
    return temp;
  }

  baseIterator& operator-=(std::size_t n) {
      for (size_t i = 0; i < n; ++i) {
          if (is_reverse) {
              iterator_ = iterator_->next;
          } else {
              iterator_ = iterator_->prev;
          }
      }
      return *this;
  }

  baseIterator operator-(std::size_t n) const {
    baseIterator temp = *this;
    temp -= n;
    return temp;
  }
};

/*
=================================================

                    LIST

=================================================
*/

template<typename T, typename Allocator=std::allocator<T>>
class List {

  BaseNode endNode;
  size_t list_size = 0;
  using NodeAlloc = typename std::allocator_traits<Allocator>::template rebind_alloc<Node<T>>;
  NodeAlloc alloc;

public:
    using iterator = baseIterator<T>;
    using const_iterator = baseIterator<T, true>;
    using reverse_iterator = baseIterator<T, false, true>;
    using const_reverse_iterator = baseIterator<T, true, true>;

    using NodeAllocatorType = typename std::allocator_traits<Allocator>::template rebind_alloc<Node<T>>;
    using NodeAllocTraits = std::allocator_traits<NodeAllocatorType>;

/*
-------------------------------------------------

         CONSTRUCTORS AND DESTRUCTOR

-------------------------------------------------
*/

    void create(const size_t count) {
        size_t created = 0;
        try {
            for (; created < count; ++created) {
                Node<T>* newNode = NodeAllocTraits::allocate(alloc, 1);
                try {
                    NodeAllocTraits::construct(alloc, newNode);
                } catch (...) {
                    NodeAllocTraits::deallocate(alloc, newNode, 1);
                    throw;
                }
                BaseNode* last = endNode.prev;
                newNode->prev = last;
                newNode->next = &endNode;
                last->next = newNode;
                endNode.prev = newNode;
                ++list_size;
            }
        } catch (...) {
            while (created--) {
                pop_back();
            }
            throw;
        }
    }

    List() noexcept
        : endNode{&endNode, &endNode},
        alloc(NodeAlloc()) {}

    List(const size_t count)
        : endNode{&endNode, &endNode},
        alloc(NodeAlloc()) {
            create(count);
    }

    List(const size_t count, const T& value)
        : endNode{&endNode, &endNode},
        alloc(NodeAlloc()) {
        for (size_t i = 0; i < count; ++i) {
            push_back(value);
        }
    }

    explicit List(const Allocator& alloc) noexcept
        : endNode{&endNode, &endNode},
        alloc(alloc) {}

    List(const size_t count, const Allocator& allocator)
        : endNode{&endNode, &endNode},
        alloc(allocator) {
        create(count);
    }

    List(const size_t count, const T& value, const Allocator& allocator)
        : endNode{&endNode, &endNode},
        alloc(allocator) {
        for (size_t i = 0; i < count; ++i) {
            push_back(value);
        }
    }

    List(const List& other)
        : endNode{&endNode, &endNode},
        alloc(NodeAllocTraits::select_on_container_copy_construction(other.alloc)) {
            try {
                for (auto it = other.begin(); it != other.end(); ++it) {
                    Node<T>* newNode = NodeAllocTraits::allocate(alloc, 1);
                    try {
                        NodeAllocTraits::construct(alloc, newNode, *it);
                    } catch (...) {
                        NodeAllocTraits::deallocate(alloc, newNode, 1);
                        throw;
                    }
                    newNode->prev = endNode.prev;
                    newNode->next = &endNode;
                    endNode.prev->next = newNode;
                    endNode.prev = newNode;
                    ++list_size;
                }
            } catch (...) {
                clear();
                throw;
            }
    }

    List(List&& other) noexcept
        : endNode{other.endNode.prev, other.endNode.next},
          list_size(other.list_size),
          alloc(std::move(other.alloc)) {

        if (!other.empty()) {
            endNode.next->prev = &endNode;
            endNode.prev->next = &endNode;
        } else {
            endNode.next = endNode.prev = &endNode;
        }
        other.endNode.next = other.endNode.prev = &other.endNode;
        other.list_size = 0;
    }

    List& operator=(const List& other) {
        if (this != &other) {
            List tmp(other);
            std::swap(endNode, tmp.endNode);
            std::swap(list_size, tmp.list_size);
            if (endNode.next != &endNode) {
                endNode.next->prev = &endNode;
                endNode.prev->next = &endNode;
            }
            if (tmp.endNode.next != &tmp.endNode) {
                tmp.endNode.next->prev = &tmp.endNode;
                tmp.endNode.prev->next = &tmp.endNode;
            }
            if constexpr (NodeAllocTraits::propagate_on_container_copy_assignment::value) {
                alloc = other.alloc;
            }
        }
        return *this;
    }

    List& operator=(List&& other) noexcept {
        if (this != &other) {
            clear();
            if constexpr (NodeAllocTraits::propagate_on_container_move_assignment::value) {
                alloc = std::move(other.alloc);
            }
            endNode.next = other.endNode.next;
            endNode.prev = other.endNode.prev;
            list_size = other.list_size;

            if (!empty()) {
                endNode.next->prev = &endNode;
                endNode.prev->next = &endNode;
            } else {
                endNode.next = endNode.prev = &endNode;
            }
            other.endNode.next = other.endNode.prev = &other.endNode;
            other.list_size = 0;
        }
        return *this;
    }

    ~List() {
        clear();
    }

/*
-------------------------------------------------

          METHODS, GETTERS AND SETTERS

-------------------------------------------------
*/

    Allocator get_allocator() const {
        return alloc;
    }

    [[nodiscard]] size_t size() const {
        return list_size;
    }

    [[nodiscard]] bool empty() const {
        return list_size == 0;
    }

    void clear() {
        while (!empty()) {
            pop_back();
        }
    }

    template<typename... UArgs>
    iterator emplace(const_iterator pos, UArgs&&... args) {
        Node<T>* newNode = NodeAllocTraits::allocate(alloc, 1);
        try {
            Allocator dataAlloc{};
            std::allocator_traits<Allocator>::construct(
                dataAlloc,
                std::addressof(newNode->value),
                std::forward<UArgs>(args)...
            );
        } catch (...) {
            NodeAllocTraits::deallocate(alloc, newNode, 1);
            throw;
        }
        BaseNode* currentNode = pos.node();
        BaseNode* prevNode = currentNode->prev;
        newNode->prev = prevNode;
        newNode->next = currentNode;
        prevNode->next = newNode;
        currentNode->prev = newNode;
        ++list_size;
        return iterator(static_cast<BaseNode*>(newNode));
    }


    iterator insert(const_iterator pos, const T& value) {
        Node<T>* newNode = NodeAllocTraits::allocate(alloc, 1);
        try {
            NodeAllocTraits::construct(alloc, newNode, value);
        } catch (...) {
            NodeAllocTraits::deallocate(alloc, newNode, 1);
            throw;
        }
        BaseNode* currentNode = pos.node();
        BaseNode* prevNode = currentNode->prev;
        BaseNode* nextNode = currentNode;
        newNode->prev = prevNode;
        newNode->next = nextNode;
        prevNode->next = newNode;
        currentNode->prev = newNode;
        ++list_size;
        return iterator(static_cast<BaseNode*>(newNode));
    }

    iterator insert(const_iterator pos, T&& value) {
        Node<T>* newNode = NodeAllocTraits::allocate(alloc, 1);
        try {
            NodeAllocTraits::construct(alloc, newNode, std::move(value));
        } catch (...) {
            NodeAllocTraits::deallocate(alloc, newNode, 1);
            throw;
        }

        BaseNode* currentNode = pos.node();
        BaseNode* prevNode = currentNode->prev;
        newNode->prev = prevNode;
        newNode->next = currentNode;
        prevNode->next = newNode;
        currentNode->prev = newNode;
        ++list_size;
        return iterator(static_cast<BaseNode*>(newNode));
    }

    iterator erase(const_iterator pos) {
        if (empty()) {
            throw std::out_of_range("List is empty");
        }
        BaseNode* nodeToDeleteBase = pos.node();
        Node<T>* nodeToDelete = static_cast<Node<T>*>(nodeToDeleteBase);
        BaseNode* nextNode = nodeToDelete->next;

        nodeToDelete->prev->next = nodeToDelete->next;
        nodeToDelete->next->prev = nodeToDelete->prev;

        NodeAllocTraits::destroy(alloc, nodeToDelete);
        NodeAllocTraits::deallocate(alloc, nodeToDelete, 1);
        --list_size;

        return iterator(nextNode);
    }

/*
-------------------------------------------------

               PUSH AND POP

-------------------------------------------------
*/

    void push_back(const T& value) {
      insert(end(), value);
    }

    void push_back(T&& value) {
      insert(end(), value);
    }

    void push_front(const T& value) {
      insert(begin(), value);
    }

    void push_front(T&& value) {
      insert(begin(), value);
    }

    void pop_back() {
        if (empty()) {
            throw std::out_of_range("List is empty");
        }
        iterator my_iterator = end();
        --my_iterator;
        erase(my_iterator);
    }

    void pop_front() {
        if (empty()) {
            throw std::out_of_range("List is empty");
        }
        erase(begin());
    }

/*
-------------------------------------------------

              CREATE LIST ITERATORS

-------------------------------------------------
*/

    iterator begin() noexcept {
        return iterator(endNode.next);
    }

    const_iterator begin() const noexcept {
        return const_iterator(const_cast<BaseNode*>(endNode.next));
    }

    iterator end() noexcept {
        return iterator(&endNode);
    }

    const_iterator end() const noexcept {
        return const_iterator(const_cast<BaseNode*>(&endNode));
    }

    reverse_iterator rbegin() noexcept {
        return reverse_iterator(endNode.prev);
    }

    const_reverse_iterator rbegin() const noexcept {
        return const_reverse_iterator(const_cast<BaseNode*>(endNode.prev));
    }

    reverse_iterator rend() noexcept {
        return reverse_iterator(&endNode);
    }

    const_reverse_iterator rend() const noexcept {
        return const_reverse_iterator(const_cast<BaseNode*>(&endNode));
    }

    const_iterator cbegin() const noexcept {
        return const_iterator(const_cast<BaseNode*>(endNode.next));
    }

    const_iterator cend() const noexcept {
        return const_iterator(const_cast<BaseNode*>(&endNode));
    }

    const_reverse_iterator crbegin() const noexcept {
        return const_reverse_iterator(const_cast<BaseNode*>(endNode.prev));
    }

    const_reverse_iterator crend() const noexcept {
        return const_reverse_iterator(const_cast<BaseNode*>(&endNode));
    }
};

/*
=================================================

                UNORDERED MAP

=================================================
*/

template<typename Key,
        typename Value,
        typename Hash = std::hash<Key>,
        typename EqualTo = std::equal_to<Key>,
        typename Alloc = std::allocator<std::pair<const Key, Value>>>
class UnorderedMap {
public:
  	static constexpr size_t INIT_BUCKET_SIZE = 16;
    double MAX_LOAD_FACTOR = 1.0;

    using NodeType = std::pair<const Key, Value>;
    using NodeAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<NodeType>;
    using AllocTraits = std::allocator_traits<NodeAlloc>;

private:
    struct Bucket {
        typename List<NodeType, NodeAlloc>::iterator begin;
        typename List<NodeType, NodeAlloc>::iterator end;
    };

public:
    using BucketAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<Bucket>;

private:
    List<NodeType, NodeAlloc> elements;
    std::vector<Bucket, BucketAlloc> buckets;
    size_t element_count = 0;
    [[no_unique_address]] Hash hasher;
    [[no_unique_address]] EqualTo key_equal;
    [[no_unique_address]] Alloc alloc;

/*
=================================================

           UNORDERED MAP ITERATORS

=================================================
*/

    template <bool is_const>
    class Iterator {
    public:
        using iterator_category = std::forward_iterator_tag;
        using value_type = NodeType;
        using difference_type = std::ptrdiff_t;
        using reference = std::conditional_t<is_const, const value_type&, value_type&>;
        using pointer = std::conditional_t<is_const, const value_type*, value_type*>;

    private:
        using list_iterator = std::conditional_t<is_const,
            				  typename List<NodeType, NodeAlloc>::const_iterator,
                              typename List<NodeType, NodeAlloc>::iterator>;

        list_iterator iterator_;

    public:
        Iterator() = default;

        explicit Iterator(list_iterator iterator) : iterator_(iterator) {}

        [[nodiscard]] list_iterator get_iterator() const {
            return iterator_;
        }

        template<bool other_const, typename = std::enable_if_t<is_const >= other_const>>
        Iterator(const Iterator<other_const> other)
            : iterator_(other.get_iterator()) {}

        reference operator*() const {
          return *iterator_;
        }
        pointer operator->() const {
          return &(*iterator_);
        }

        Iterator& operator++() {
            ++iterator_;
            return *this;
        }

        Iterator operator++(int) {
            Iterator tmp = *this;
            ++(*this);
            return tmp;
        }

        bool operator==(const Iterator& other) const {
            return iterator_ == other.iterator_;
        }

        bool operator!=(const Iterator& other) const {
            return !(*this == other);
        }
    };

public:
    using iterator = Iterator<false>;
    using const_iterator = Iterator<true>;

/*
-------------------------------------------------

         CONSTRUCTORS AND DESTRUCTOR

-------------------------------------------------
*/

    UnorderedMap() : UnorderedMap(INIT_BUCKET_SIZE) {}

    explicit UnorderedMap(size_t bucket_count,
                         const Hash& hash = Hash(),
                         const EqualTo& equal = EqualTo(),
                         const Alloc& alloc = Alloc())
        : buckets(bucket_count),
          hasher(hash),
          key_equal(equal),
          alloc(alloc) {}

    UnorderedMap(const UnorderedMap& other)
        : buckets(other.buckets.size()),
          hasher(other.hasher),
          key_equal(other.key_equal),
          alloc(AllocTraits::select_on_container_copy_construction(other.alloc)) {
        try {
            for (const auto& elem : other) {
                insert(elem);
            }
        } catch (...) {
            clear();
            std::vector<Bucket, BucketAlloc>().swap(buckets);
            element_count = 0;
            throw;
        }
    }

    UnorderedMap(UnorderedMap&& other) noexcept
        : elements(std::move(other.elements)),
          buckets(std::move(other.buckets)),
          element_count(other.element_count),
          hasher(std::move(other.hasher)),
          key_equal(std::move(other.key_equal)),
          alloc(std::move(other.alloc)) {
        other.element_count = 0;
    }

    UnorderedMap& operator=(const UnorderedMap& other) {
        if (this != &other) {
            clear();
            if (AllocTraits::propagate_on_container_copy_assignment::value) {
                alloc = other.alloc;
            }
            buckets.resize(other.buckets.size());
            hasher = other.hasher;
            key_equal = other.key_equal;
            for (const auto& elem : other) {
                insert(elem);
            }
        }
        return *this;
    }

    UnorderedMap& operator=(UnorderedMap&& other) noexcept {
        if (this != &other) {
            clear();
            if (AllocTraits::propagate_on_container_move_assignment::value) {
                alloc = std::move(other.alloc);
            }
            elements = std::move(other.elements);
            buckets = std::move(other.buckets);
            element_count = other.element_count;
            hasher = std::move(other.hasher);
            key_equal = std::move(other.key_equal);
            other.element_count = 0;
        }
        return *this;
    }

    ~UnorderedMap() = default;

/*
-------------------------------------------------

          METHODS, GETTERS AND SETTERS

-------------------------------------------------
*/

    [[nodiscard]] size_t size() const noexcept {
      return element_count;
    }

    [[nodiscard]] bool empty() const noexcept {
      return element_count == 0;
    }

    void clear() noexcept {
        elements.clear();
        for (auto& bucket : buckets) {
            bucket.begin = typename List<NodeType, NodeAlloc>::iterator();
            bucket.end = typename List<NodeType, NodeAlloc>::iterator();
        }
        element_count = 0;
    }

    size_t get_bucket_index(const Key& key) const {
        return hasher(key) % buckets.size();
    }

    void swap(UnorderedMap& other) noexcept {
        std::swap(elements, other.elements);
        std::swap(buckets, other.buckets);
        std::swap(element_count, other.element_count);
        std::swap(hasher, other.hasher);
        std::swap(key_equal, other.key_equal);
        if (AllocTraits::propagate_on_container_swap::value) {
            std::swap(alloc, other.alloc);
        }
    }

/*
-------------------------------------------------

            REHASH AND HIS FRIENDS

-------------------------------------------------
*/

    void rehash(size_t new_size) {
        if (new_size == 0) {
            new_size = 1;
        }
        buckets.clear();
        buckets.resize(new_size);

        for (auto it = elements.begin(); it != elements.end(); ++it) {
            size_t idx = hasher(it->first) % new_size;
            if (buckets[idx].begin == typename List<NodeType, NodeAlloc>::iterator()) {
                buckets[idx].begin = it;
            }
            buckets[idx].end = std::next(it);
        }
    }

    [[nodiscard]] double load_factor() const noexcept {
        return static_cast<double>(size()) / buckets.size();
    }

    void check_rehash() {
        if (load_factor() > MAX_LOAD_FACTOR) {
            rehash(buckets.size() * 2);
        }
    }

    [[nodiscard]] double max_load_factor() const noexcept {
        return MAX_LOAD_FACTOR;
    }

    void max_load_factor(const double new_max_load_factor) {
        if (new_max_load_factor > 0) {
            MAX_LOAD_FACTOR = new_max_load_factor;
            check_rehash();
        }
    }

    void reserve(const size_t count) {
        const size_t new_bucket_count = static_cast<size_t>(count / MAX_LOAD_FACTOR) + 1;
        rehash(new_bucket_count);
    }

/*
-------------------------------------------------

                     EMPLACE

-------------------------------------------------
*/

    template <typename KArg, typename VArg>
    std::pair<iterator, bool> emplace(KArg&& keyArg, VArg&& valueArg) {
        check_rehash();

        alignas(NodeType) unsigned char tmpBuf[sizeof(NodeType)];
        NodeType* tmpPair = reinterpret_cast<NodeType*>(tmpBuf);
        AllocTraits::construct(alloc, tmpPair,
            std::forward<KArg>(keyArg),
            std::forward<VArg>(valueArg)
        );

        const Key& newKey = tmpPair->first;
        size_t idx = get_bucket_index(newKey);

        if (buckets[idx].begin.node() != nullptr) {
            for (auto it = buckets[idx].begin; it != elements.end(); ++it) {
                if (key_equal(it->first, newKey)) {
                    AllocTraits::destroy(alloc, tmpPair);
                    return { iterator(it), false };
                }
            }
        }

        auto listIt = elements.emplace(
            elements.end(),
            std::forward<KArg>(keyArg),
            std::forward<VArg>(valueArg)
        );

        AllocTraits::destroy(alloc, tmpPair);

        if (buckets[idx].begin.node() == nullptr) {
            buckets[idx].begin = listIt;
        }
        buckets[idx].end = std::next(listIt);

        ++element_count;
        return { iterator(listIt), true };
    }

/*
-------------------------------------------------

                    INSERT

-------------------------------------------------
*/

    std::pair<iterator,bool> insert(const NodeType& value) {
        return emplace(value.first, value.second);
    }
    std::pair<iterator,bool> insert(NodeType&& value) {
        return emplace(std::move(const_cast<Key&>(value.first)),
                       std::move(value.second));
    }

    template <typename InputIt>
    void insert(InputIt first, InputIt last) {
        for (; first != last; ++first) {
            insert(*first);
        }
    }

/*
-------------------------------------------------

                     ERASE

-------------------------------------------------
*/

    iterator erase(const_iterator pos) {
        if (pos == end()) {
            return end();
        }

        size_t index = get_bucket_index(pos->first);
        auto list_it = pos.get_iterator();
        bool is_begin = (list_it == buckets[index].begin);
        const bool is_end = (std::next(list_it) == buckets[index].end);

        auto next_list_it = elements.erase(list_it);
        --element_count;

        iterator next(next_list_it);
        const_iterator end_it = end();

        if (is_begin) {
            buckets[index].begin = (next_list_it == end_it.get_iterator() ?
                typename List<NodeType, NodeAlloc>::iterator() :
                next_list_it);
        }
        if (is_end) {
            buckets[index].end = (is_begin ? buckets[index].begin : next_list_it);
        }
        return next;
    }

    size_t erase(const Key& key) {
        auto it = find(key);
        if (it != end()) {
            erase(it);
            return 1;
        }
        return 0;
    }

    void erase(const_iterator first, const_iterator last) {
        auto listEnd = elements.end();

        while (first.get_iterator() != last.get_iterator()) {
            first = erase(first);
        }

        if (last.get_iterator() == listEnd) {
            rehash(buckets.size());
        }
    }

/*
-------------------------------------------------

                     FIND

-------------------------------------------------
*/

    iterator find(const Key& key) {
        if (buckets.empty()) {
          return end();
        }

        size_t index = get_bucket_index(key);
        for (auto it = buckets[index].begin; it != buckets[index].end; ++it) {
            if (key_equal(it->first, key)) {
                return iterator(it);
            }
        }
        return end();
    }

    const_iterator find(const Key& key) const {
        if (buckets.empty()) {
          return end();
        }

        size_t index = get_bucket_index(key);
        for (auto it = buckets[index].begin; it != buckets[index].end; ++it) {
            if (key_equal(it->first, key)) {
                return const_iterator(it);
            }
        }
        return end();
    }

/*
 -------------------------------------------------

                   GET BY INDEX

-------------------------------------------------
*/

    Value& operator[](const Key& key) {
        auto [it, inserted] = emplace(key, Value());
        return it->second;
    }


    Value& at(const Key& key) {
        auto it = find(key);
        if (it == end()) {
            throw std::out_of_range("Key not found");
        }
        return it->second;
    }

    const Value& at(const Key& key) const {
        auto it = find(key);
        if (it == end()) {
            throw std::out_of_range("Key not found");
        }
        return it->second;
    }

/*
-------------------------------------------------

           CREATE UNORDERED MAP ITERATORS

-------------------------------------------------
*/

    iterator begin() noexcept {
      return iterator(elements.begin());
    }

    const_iterator begin() const noexcept {
      return const_iterator(elements.begin());
    }

    iterator end() noexcept {
      return iterator(elements.end());
    }

    const_iterator end() const noexcept {
      return const_iterator(elements.end());
    }

    const_iterator cbegin() const noexcept {
      return begin();
    }

    const_iterator cend() const noexcept {
      return end();
    }
};
